<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class details_of_citizen extends Model
{
    use HasFactory;
    public $timestamps=false;
    protected $fillable = [
        'id',
        'Full_name',
        'date_of_birth', 
        'Education',
        'Complete_address',
        'District',
        'Taluka',
        'Village',
        'Mobile_no',
        'Income_source',
        'Own_house',
        'home_type',
        'Water_closet',
        'Bathroom',
        'stove_type',
        'Land_ownership',
        'Land_dispute',
        'Bank_account',
        'Bank_type',
        'any_disease',
        'Hospital_type',
        'Regular_check_up',
        'are_you_handicapped',
        'daily_chores',
        'aadhar_card',
        'aadhar_discrepancy',
        'Voter_id',
        'Ration_card',
        'ST_pass',
        'Govt_schemes',
        'income_increase',
        'tools_required',
        'social_service',
        'any_comment',
        'any_difficulties',
        'designated_officer_name',
        'designated_officer_contact_no',
    ];
}
