<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class citizen_govt_schemes extends Model
{
    use HasFactory;
    public $timestamps=false;
    protected $fillable = [
        'Govt_scheme_id',
    ];
}
